// ga_bool.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"  
#include <time.h>                      // define time()
#include "randomc.h"                   // define classes for random number generators
#include "stdio.h"
#include "stdlib.h"
#include "mersenne.cpp"                // members of class TRandomMersenne
#pragma warning(disable:4996) //crt_warning hatas� engelleme k�sayolu       

#define N 1024//16//262144//4096//1024//256//67108864//16777216//4194304//1048576//262144//65536//16384//4096//256//67108864//16777216//4194304//65536//262144//1048576//262144//65536//16384//4096//1024//256//67108864//65536//16384//4096//65536//262144//67108864//16777216//4194304//1048576//   //length of truth table
#define n 10//4//18//12//8//26//24//22//20//18//16//14//12//8//26//24//22//16//18//20//18//16//14//12//10//8//26//16//14//12//16//26//24///22//20		//number of variables
#define NLb  496//6//130816//2016//496//120//33550336//8386560//2096128//523776//130816//32640//8128//2016//120//33550336//8386560//2096128//32640//130816//523776//130816//32640//8128//2016//496//120//33550336//32640//8128///2016//32640//130816//2096128//523776    // max. nonlinearity
#define nlin 32//4//512//64//32//16//8192//4096//2048//1024//512//256//128//64//16//8192//4096//2048//256//512//1024//512//256//128//64//32//16//8192//256//128//64//256//512//4096//8192//1024		//2^(n/2)
#define scst 1      // 1: our cost 2: paper's cost
#define SLC	1 // 1: bizim selection 2: sugo'nun selection 
#define NSC 3 // 1: our k-NS 2: sugo's k-NS 3: our k-NSx

#define KNS 2 // number of neighbors
#define psize 1000  //initial population   
#define K  40  // parent size
#define Kb 100  // number of best selections
#define EPR 60  // % olasılık (Parent'daki "elite"lerin olasılıgı)

#define Ka 2000000  // number of runs
#define maxgen 20000 // number of iterations (generations)
#define ktour 3 //turnuva b�y�kl���
#define ELT	 EPR*K/100 //elite fonksiyon say�s� (selection i�in)
#define KTR  K-ELT //k-turnava elde edilen say�s� (selection i�in)            
#define STP 20 // stopping criteria
#define CPR 100 // Crossover probability 
#define nez nlin/2		//2^(n/2-1)
//#define nuz N/2+nez //number of zeros of a bent function       

long double mutcost;   
signed char *AT=(signed char *)malloc(N*sizeof(signed char));  
signed char *BT=(signed char *)malloc(N*sizeof(signed char));                    

int cek=0,BNL=-1,bnl=-1,BAC=1000000,bac=1000000;
int *bix=(int *)malloc(nez*sizeof(int));
int *cix=(int *)malloc(nez*sizeof(int));

int *JB=(int *)malloc(N*sizeof(int));
signed char *BNT=(signed char *)malloc(N*sizeof(signed char));	

int32 ir,ir1,ir2;                            // random integer number
int32 seed = (unsigned int) time(0);                // random seed

int *BE=(int *)malloc(Kb*nez*sizeof(int));
signed char *H=(signed char *)malloc(N*sizeof(signed char));

FILE *out=fopen("Best_Solutions.txt", "w");
FILE *outs=fopen("stats.txt", "w");

int _tmain(int argc, _TCHAR* argv[])   
{

	if (JB==0 || AT==0 || BT==0 || H==0 || BE==0 || BNT==0 || bix==0 || cix==0)// || FW2==0)// (FW4==0 || ACt==0 || AC==0 || IX==0 || IY==0 || C==0 || || ID0==0 || ID1==0
	{
		printf("Memory Allocation Error1!");
		return 0;
	}

	int weight(signed char *B);     
	int bal_chk(signed char *B);  
	int findmaxwh(long double *tt);
	void gen_bent(signed char *B);
	void make_bal(signed char *B);
	long double sumsse(long double *FW);
	int find_min(long double *COST, int R);
	void tohex(int *TT, unsigned int *tt);
	int findmaxac(int *tt);
	void mutation_rnd(signed char *B, long double *FW);
	void select_ours(int p_size, long double *CSTF, long double *CSTB, int *BF, int *BP);

	void fastwh(signed char *T, long double *FW);
	void fastwhld(long double *FW, long double *TTs);
	int acor(long double *FW);
	int anf(signed char *TT);	
	void breed_new(signed char *P1, signed char *P2, signed char *CH);

	time_t rawtime;
	struct tm * timeinfo;//usage of localtime() function.

	int *BA,*CHA,*BP,*BF;
	int *BB;
	int i,j,k,t,NL,cnt,J,ACR,kt,d;
	unsigned int cntm=0,idx,cnl=0,KA;
	long double *COST,Cr;

	int *NLA=(int *)malloc(maxgen*sizeof(int));
	signed char *B=(signed char *)malloc(N*sizeof(signed char));	
	long double *CSTB=(long double *)malloc(K*sizeof(long double));	
	long double *CSTC=(long double *)malloc(K*(K-1)/2*sizeof(long double));	
	long double *CSTF=(long double *)malloc((K+K*(K-1)/2)*sizeof(long double));	

	long double *FW=(long double *)malloc(N*sizeof(long double));	
	signed char *P1=(signed char *)malloc(N*sizeof(signed char));	
	signed char *P2=(signed char *)malloc(N*sizeof(signed char));	
	signed char *CH=(signed char *)malloc(N*sizeof(signed char));	

	if (P1==0 || P2==0 || FW==0 || CH==0 || B==0 || NLA==0 || CSTB==0 || CSTC==0 || CSTF==0)
	{
		printf("Memory Allocation Errorx!");
		return 0;
	}

	CHA=(int *)malloc((K+K*(K-1)/2)*nez*sizeof(int));	
	BB=(int *)malloc(maxgen*nez*sizeof(int));	
	BA=(int *)malloc(psize*nez*sizeof(int));	
	BP=(int *)malloc(K*nez*sizeof(int));	
	BF=(int *)malloc((K+K*(K-1)/2)*nez*sizeof(int));	
	COST=(long double *)malloc(psize*sizeof(long double));	

	if (JB==0 || FW==0 || BB==0 || AT==0 || BT==0 || CHA==0 || BA==0 || BP==0 || BF==0 || COST==0 || B==0 || P1==0 || P2==0 || CH==0 || H==0 || BE==0 || BNT==0)// || FW2==0)// (FW4==0 || || ACt==0 AC==0 || IX==0 || IY==0 || C==0 || || ID0==0 || ID1==0
	{
		printf("Memory Allocation Error!");
		return 0;
	}
	/********************************
	hadamard[0][0] = 1;
    for (int k = 1; k < n; k += k) {
		for (int i = 0; i < k; i++) {
			for (int j = 0; j < k; j++) {
				hadamard[i + k][j] = hadamard[i][j];
				hadamard[i][j + k] = hadamard[i][j];
				hadamard[i + k][j + k] = -hadamard[i][j];}}}
		**********************************/
	H[0]=1;
    for(k=1;k<nlin;k+=k){                           
        for(int i=0;i<k;i++){
            for(int j=0;j<k;j++){
                H[(i+k)*nlin+j]=H[i*nlin+j]; //[nlin]*[nlin] mesela 16*16'lık hadamard matrisimiz.
                H[i*nlin+j+k]=H[i*nlin+j];//H[0] değerleri indislere atanıyor.
                H[(i+k)*nlin+j+k]=-H[i*nlin+j];  //H[nlin]*H[nlin]; herbiri bir lineeer fonksiyona karşılık geliyor.
            }
        }
	}
	for (i=0;i<N;i++)   
		H[i]=(1-H[i])/2;//1 ve -1 olan hadamard matris değerleri 1 ve 0'a dönüştürülüyor.


	for (KA=0;KA<Ka;KA++) //Ka=2000000 run - K=40 parent size - Kb=100 number of best selections
	{
	
	time ( &rawtime );//usage of localtime() function.
	timeinfo = localtime(&rawtime);
	printf ("\n(Start) Current local time and date: %s", asctime(timeinfo));
	fprintf (out,"\n(Start) Current local time and date: %s", asctime(timeinfo));
	fclose(out);
	out=fopen("Best_Solutions.txt", "a");

	// Initial population (bent or balanced)
	gen_bent(B);
	j=0;
	for (i=0;i<N;i++)
		if (B[i]==0)
			j=j+1;
	printf("\n0's:%d",j);    // 0 ların sayısı
	j=0;
	for (i=0;i<N;i++)
		if (B[i]==1)
			j=j+1;
	printf("\n1's:%d",j);     // 1 lerin sayısı

	for (i=0;i<N;i++)
		BNT[i]=B[i];
	fastwh(B, FW);
	NL=N/2-findmaxwh(FW)/2; //en büyük walsh transformunu bulup NL hesaplıyor.
	if (NL!=NLb) //max.nonlinearity'e eşit değilse hata ver.Çünkü bent fonksiyonunu gönderdik.
	{
		printf("\nError..bent %d %d",i,NL);
		return 0;
	}

	for (i=0;i<psize;i++)
	{
		make_bal(B);
		t=bal_chk(B);
		if (t!=N/2)
		{
			printf("\nError..bal %d; %d",i,weight(B));
			return 0;
		}
		
		for (j=0;j<nez;j++)         //BA 1000*8 lik değişen indislerin yerlerini tutuyor.(psize*nez)
			*(BA+i*nez+j)=bix[j];	//Store balanced functions into BA.//make_bal ile (rasgele) 0 iken 1 yapılan indislerin yerleri bix de bulunuyor.
		fastwh(B, FW);              //BA 1000 (initial population) taneyi tutuyor.make_bal'a 1000 defa gidiyor.

///////////////////////////////////////////////////////

		NL=N/2-findmaxwh(FW)/2;
		if (bnl<NL)   //bnl=-1
			bnl=NL;

//////////////////////////////////////////////////////

		if (scst==1)
			COST[i]=sumsse(FW);		//Compute and store costs of balanced function into COST
									//Lineer fonksiyonların sumsse'de hesaplanan cost değerleri COST dizininde tutuluyor. 
		for (j=0;j<N;j++)
			B[j]=BNT[j];
		printf("\ni=%d (psize) => NL=%d cost=%f",i,NL,COST[i]);//psize=1000 adet initial populasyon ekrana yazdırılıyor.
	}	//1000 adet dengeli fonksiyon ürettik.
	// Selection
	if (SLC==1)
		select_ours(psize, COST, CSTB, BA, BP); //BA=initial population - BP=40'ini seçtik.
	/*CHA=(int *)malloc((K+K*(K-1)/2)*nez*sizeof(int));	
	BB=(int *)malloc(maxgen*nez*sizeof(int));	
	BA=(int *)malloc(psize*nez*sizeof(int));  -----  1000*8 lik bixlerin tutulduğu balanced function.
	BP=(int *)malloc(K*nez*sizeof(int));	  ----- 40*8 lik best parents  
	BF=(int *)malloc((K+K*(K-1)/2)*nez*sizeof(int));	
	int *BE=(int *)malloc(Kb*nez*sizeof(int));
	COST=(long double *)malloc(psize*sizeof(long double)); ---  1000
	int *NLA=(int *)malloc(maxgen*sizeof(int));
	signed char *B=(signed char *)malloc(N*sizeof(signed char));	
	long double *CSTB=(long double *)malloc(K*sizeof(long double));	----  40
	long double *CSTC=(long double *)malloc(K*(K-1)/2*sizeof(long double));	
	long double *CSTF=(long double *)malloc((K+K*(K-1)/2)*sizeof(long double));	*/

	
	// CurrSol'a Parent'i yerlestir.
	for (i=0;i<K;i++) //K=40
	{
		for (j=0;j<nez;j++)
			*(BF+i*nez+j)=*(BP+i*nez+j);  //BF(40,2)+40 ---- [40*8]

		CSTF[i]=CSTB[i];   //CSTF(40,2)+40
	}
	kt=0;
	// maxgen = number of generations  
	for (J=0;J<maxgen;J++)
	{

		// Child'lari uret (crossover/breed)
		cnt=0;
		for (i=0;i<K-1;i++)      // K=40
			for (j=i+1;j<K;j++)
			{

				cek=cek+10;
				seed=(unsigned int) time(0)+cek;
				TRandomMersenne rg(seed);            // make instance of random number generator
				ir = rg.IRandom(1,100); 

				if (ir>100-CPR)   //CPR=100 - %100 crossover uygula.
				{
					for (k=0;k<N;k++)	P1[k]=BNT[k];
					for	(k=0;k<nez;k++)	P1[BP[i*nez+k]]=BNT[BP[i*nez+k]]^1;//En iyi cost değerlerine bağlı kalınarak 
																		   //BP indisindeki bit ile 8 defa XOR yap.

					for (k=0;k<N;k++)	P2[k]=BNT[k];
					for	(k=0;k<nez;k++)	P2[BP[j*nez+k]]=BNT[BP[j*nez+k]]^1;
		
					breed_new(P1,P2,CH);
					
					for (k=0;k<nez;k++)
						*(CHA+cnt*nez+k)=cix[k];	// Store CH into CHA ---(780+40)*8
					fastwh(CH,FW);

///////////////////////////////////////////////////////

					NL=N/2-findmaxwh(FW)/2;
					if (bnl<NL)
						bnl=NL;

//////////////////////////////////////////////////////

					if (scst==1)
						CSTC[cnt]=sumsse(FW); 	// Store cost of CH into CSTC = child costu

					cnt = cnt + 1;
				}
			}
			
		//Child'lara mutation uygula
		for (i=0;i<cnt;i++)// K=40 ; (40,2) => cnt=780
		{
			for (k=0;k<N;k++)	CH[k]=BNT[k];
			for (k=0;k<nez;k++)	CH[CHA[i*nez+k]]=BNT[CHA[i*nez+k]]^1;//Childe'ın Bent'den hangi bitleri farklıysa
														//Bent'de mutasyon yapıp childın indislerine atadık.
			mutcost=CSTC[i];
			mutation_rnd(CH,FW);

			for (k=0;k<nez;k++)
				*(CHA+i*nez+k)=cix[k];
			CSTC[i]=mutcost;
		}

		
		// Child'lari CurSol'a aktar (cost dahil)
		for (i=0;i<cnt;i++)
		{
			for (j=0;j<nez;j++)
				*(BF+(i+K)*nez+j)=*(CHA+i*nez+j);//childları best family'e [BF=BF+CHA] ekle.780+40
			CSTF[i+K]=CSTC[i];  // CSTF => 780+40
		}

		// Selection
		if (SLC==1)//K+cnt=40+780 ----  CSTF=CSTF+CSTC=820 ---- CSTB= 40 --- BF= 820 ---- BP=40
			select_ours(K+cnt, CSTF, CSTB, BF, BP);

		/////////////////////////////////////////////////////////////

		for (i=0;i<K;i++)
		{
			for (k=0;k<N;k++)	CH[k]=BNT[k];
			for (k=0;k<nez;k++)	CH[BP[i*nez+k]]=BNT[BP[i*nez+k]]^1;
			fastwh(CH,FW);
			NL=N/2-findmaxwh(FW)/2;
			if (bnl<NL)
				bnl=NL;
		}

		////////////////////////////////////////////


		idx=find_min(CSTB,K);
		if (idx==-1)
		{
			printf("\nError..idx=%d",idx);
			return 0;
		}

		for (i=0;i<N;i++)	B[i]=BNT[i];
		for (i=0;i<nez;i++)	B[BP[idx*nez+i]]=BNT[BP[idx*nez+i]]^1;	// B: best function having minimum cost

		for (i=0;i<nez;i++)
			*(BB+J*nez+i)=BP[idx*nez+i];		// Store B into BB

		Cr=CSTB[idx];		//Store min. cost
		for (i=0;i<nez;i++)
			cix[i]=BP[idx*nez+i];		// Store B as Br
		if (J>0)
		{
			j=0;
			for (i=0;i<nez;i++)
				if (*(BB+(J-1)*nez+i)==cix[i])
					j=j+1;
			if (j==nez)
				kt=kt+1;		// Number of repetitions
			else
				kt=0;
			if (kt==STP)
				kt=0;
		}

		fastwh(B,FW);
		NL=N/2-findmaxwh(FW)/2;
		NLA[J]=NL;

		if (NL>BNL)
			BNL=NL;

		ACR=acor(FW);
		if (bac>ACR)
			bac=ACR;
		d=anf(B);
		k=0;
		for (i=0;i<K;i++)
			if (CSTB[i]==CSTB[idx]) //CSTB burada eşleşmeden sonraki en küçük cost değerlerini tutuyor.
				k=k+1;					// k: Number of functions with the same best cost

		//if (J%100==0)
		{

			printf("\nRun#:%d, G:%d (Cst=%10.0f; NL=%d AC=%d d=%d sf=%d sc=%d BNL=%d bnl=%d bac=%d): idx=%d",KA,J,CSTB[idx],NL,ACR,d,kt,k,BNL,bnl,bac,idx);
			fprintf(out,"\nRun#:%d, G:%d (Cst=%10.0f; NL=%d AC=%d d=%d sf=%d sc=%d BNL=%d bnl=%d bac=%d): idx=%d\n",KA,J,CSTB[idx],NL,ACR,d,kt,k,BNL,bnl,bac,idx);
		}
			
		if ((n==24 && (NL>=8386522 || ACR<=936)) || (n==18 && (NL>=130800 || ACR<=256)) || (n==20 && (NL>=523756 || ACR<=408)) || (n==22 && (NL>=2096096 || ACR<=600)) || (n==26 && (NL>=33550272 || ACR<=1368)) || (n==16 && (NL>=32628 || ACR<=152)) || (n==14 && (NL>=8120 || ACR<=88)) || (n==12 && (NL>=2010 || ACR<=40)) || (n==10 && (NL>=492 || ACR<=24)) || (n==8 && (NL>116 || ACR<=16))  || (n==6 && (NL>24 || ACR<=16)))
		{
			printf("\nRun#:%d, G:%d (Cst=%10.0f; NL=%d AC=%d d=%d sf=%d sc=%d BNL=%d bnl=%d bac=%d):",KA,J,CSTB[idx],NL,ACR,d,kt,k,BNL,bnl,bac);
			fprintf(out,"\nRun#:%d, G:%d (Cst=%10.0f; NL=%d AC=%d d=%d sf=%d sc=%d BNL=%d bnl=%d bac=%d): \n",KA,J,CSTB[idx],NL,ACR,d,kt,k,BNL,bnl,bac);
			for (i=0;i<N;i++)
				fprintf(out,"%d ",B[i]);
		}

		for (i=0;i<K;i++)    
		{
			for (j=0;j<nez;j++)
				*(BF+i*nez+j)=*(BP+i*nez+j);
			CSTF[i]=CSTB[i];
		}
		if (k==K || kt==STP)
		{
			for (i=0;i<psize;i++)
			{
				for (j=0;j<N;j++)
					B[j]=BNT[j];
				make_bal(B);
				t=bal_chk(B);
				if (t!=N/2)
				{
					printf("\nError..bal %d; %d",i,weight(B));
					return 0;
				}
				for (j=0;j<nez;j++)
					*(BA+i*nez+j)=bix[j];	//Store balanced functions into BA
				fastwh(B, FW);

		///////////////////////////////////////////////////////

				NL=N/2-findmaxwh(FW)/2;
				if (bnl<NL)
					bnl=NL;

		//////////////////////////////////////////////////////

				if (scst==1)
					COST[i]=sumsse(FW);		//Compute and store costs of balanced function into COST
			}
			// Selection
			if (SLC==1)
				select_ours(psize, COST, CSTB, BA, BP);
			CSTB[K-1]=Cr;
			i=K-1;
			for (j=0;j<nez;j++)
				*(BP+i*nez+j)=cix[j];
			// CurrSol'a Parent'a yerleStir
			for (i=0;i<K;i++)
			{
				for (j=0;j<nez;j++)
					*(BF+i*nez+j)=*(BP+i*nez+j);
				CSTF[i]=CSTB[i];  
			}
		}

	}

	printf("\nKA=%d Best NL=%d (%d)",KA,j,cnl);

	fprintf(outs,"%d ",j);
	fclose(outs);
	outs=fopen("stats.txt", "a");

	fclose(out);
	out=fopen("Best_Solutions.txt", "a");


	}//for KA<Ka
	fclose(out);
	fclose(outs);
	return 0;
}

int anf(signed char *TT)//cebirsel derece
{
	int i,j;
	for (i=0;i<N;i++)	AT[i]=TT[i];
	int t1=1,t2,Zx,l1,l2,lx,u1,u2,ux;
	for (int k=0;k<n;k++)
	{
		t1=t1*2;
		t2=t1/2;
		Zx=N/t1;
		for (int b=0;b<Zx;b++)
		{
			i=2*b;
			l1=t2*i;	u1=t2*(i+1);
			l2=t2*(i+1);u2=t2*(i+2);
			lx=t1*b;	ux=t1*(b+1);
			for (int j=l1;j<u1;j++)
			{
				BT[lx]=AT[j];
				lx=lx+1;
			}
			for (int j=l2;j<u2;j++)
			{
				BT[lx]=AT[j]^AT[l1];
				lx=lx+1;l1=l1+1;
			}
		}
		for (j=0;j<N;j++)
			AT[j]=BT[j];
	}
	int ad=0,d;
	for (i=0;i<N;i++)
		if (AT[i]!=0)
		{
			d=0;
			for (j=0;j<n;j++)
				if ((i&(1<<j))!=0)
					d=d+1;
			if (d>ad)
				ad=d;

		}
	return ad;
}

void fastwh(signed char *T, long double *FW) // T => B ; FW => FW gönderiliyor.
{	
	int i,j,i1,i2,i3,k1=2,k2=N/2,k3=1,L1;
	long double temp1,temp2;
	for (i=0;i<N;i++)
		//printf("FW[%d]=%d", i, FW[i]);
		/((long double) T[i]);		
	for (i1=0;i1<n;i1++)  //Walsh transformunu 2'e bölme metodu ile hesaplama tekniği
	{
	   L1=1;
	   for (i2=0;i2<k2;i2++) //k2=128 (N=256)
	   {
		  for (i3=0;i3<k3;i3++)//k3=1
		  {
			 i=i3+L1-1; j=i+k3; 
		     temp1= FW[i]; temp2 = FW[j]; 
			 FW[i]=temp1+temp2;
		     FW[j]=temp1-temp2;
		  }
	      L1=L1+k1; //k1=2
	   }
	   k1=k1*2; k2=k2/2; k3=k3*2;
	   //printf("FW[%d]=%d", i, FW[i]);
	}
}

int acor(long double *FW)
{
	int i,j,i1,L1,i2,i3,k1=2,k2=N/2,k3=1;
	long double temp1,temp2;
	for (i=0;i<N;i++)
		FW[i]=FW[i]*FW[i];

	for (i1=0;i1<n;i1++)  
	{
	   L1=1;
	   for (i2=0;i2<k2;i2++)
	   {
		  for (i3=0;i3<k3;i3++)
		  {
			 i=i3+L1-1; j=i+k3; 
		     temp1= FW[i]; temp2 = FW[j]; 
			 FW[i]=temp1+temp2;
		     FW[j]=temp1-temp2;
		  }
	      L1=L1+k1; 
	   }
	   k1=k1*2; k2=k2/2; k3=k3*2;
	}

	long double D,Maxi=-1;
	for (i=1;i<N;i++)
	{
		D=FW[i];
		if (FW[i]<0)
			D=-FW[i];
		if (D>Maxi)
			Maxi=D;
	}
	Maxi=Maxi/N;
	return ((int) Maxi);
}


int find_min(long double *COST, int R) //En küçük bulduğu cost değeri indisini geri döndürüyor.
{
	int i,idxmin=-1;
	long double Maxi=1.6e+50;
	for (i=0;i<R;i++)
		if (COST[i]<Maxi)
		{
			Maxi=COST[i];
			idxmin=i;
		}
	return idxmin;
}

void select_ours(int p_size, long double *CSTF, long double *CSTB, int *BF, int *BP)
{
	int i,j,k,IDX[Kb],chk,irk;

	long double CSTE[Kb],Maxi;
	int IDW[Kb];

	for (i=0;i<Kb;i++) //Kb=100
		IDW[i]=0;
	// select best Kb functions (elitism)
	for (i=0;i<Kb;i++)  //Kb=100 
	{
		IDX[i]=find_min(CSTF,p_size); //psize(parent costu içinden) içinden 100 tane en iyi costu seç,IDX'te tut.
		if (IDX[i]==-1)
		{
			printf("\nError..IDX[%d]=%d",i,IDX[i]);
			return;
		}
		CSTE[i]=CSTF[IDX[i]]; //1000 tane cost içinden 100 tane en iyi costu seçip CSTE'e atıyor.
		CSTF[IDX[i]]=1.7e+50; //tekrardan min.costu bulmak için max.yapıyor.

		for (j=0;j<nez;j++) //min.cost IDX e atanıp en iyi 100 function bulma. 
			*(BE+i*nez+j)=*(BF+IDX[i]*nez+j); //1000 taneden Kb=100 tanesi parent oldu.Best Elite (BE) oluştu.
	}
	// make k-tournament
	for (i=0;i<K;i++) // K=40 ---- 100 tane best elite içinden 40 best parent belirleme.k-turnuva yöntemi.
	{
		Maxi=1.6e+50;
		for (k=0;k<ktour;k++) //k-tour=3
		{
			chk=0;
			while (chk==0)
			{
				cek=cek+10;
				seed=(unsigned int) time(0)+cek;
				TRandomMersenne rg(seed);            // make instance of random number generator
				ir = rg.IRandom(0,Kb-1); //100 tane içinden 40'a indirgeme.
				if (IDW[ir]==0)
					chk=1;
			}
			if (CSTE[ir]<Maxi)
			{
				Maxi=CSTE[ir];
				irk=ir;
			}
		}

		for (j=0;j<nez;j++)
			*(BP+i*nez+j)=*(BE+irk*nez+j);//CSTF' i dikkate alarak 100 taneden 40 tanesini parent yaptık. BP oldu.
		CSTB[i]=Maxi;                     //CSTB 40 adet.
		IDW[irk]=1;
	}
}

int bal_chk(signed char *B)
{
	int i,s=0;
	for (i=0;i<N;i++)
		s=s+B[i];
	return s;
}

int weight(signed char *B)
{
	int i,s=0;
	for (i=0;i<N;i++)
		s=s+B[i];
	return s;
}

void breed_new(signed char *P1, signed char *P2, signed char *CH)
{
	int i,j,k,I1[nez],I2[nez],PI[nez],c1=0,c2=0,chk,kt;
	for (i=0;i<N;i++)
	{
		if (P1[i]==P2[i]) //parentda aynılar çocuğa geçsin.
			CH[i]=P1[i];
		else
			CH[i]=2;
	}
	for (i=0;i<N;i++)
	{
		if (P1[i]==1 && BNT[i]==0)
		{
			I1[c1]=i;//parent ile bent'in farklı olan yerlerinin indislerini tuttuk.
			c1=c1+1;//printf("c1=%d", c1);
		}
		if (P2[i]==1 && BNT[i]==0)//yukarıda yazılana ilave ayrıca parentların 1 olan indislerini tuttuk.
		{
			I2[c2]=i;
			c2=c2+1;//printf("c2=%d", c2);
		}
	}

	kt=0;
	for (i=0;i<nez;i++) // 0'ların sayısı:136 ; 1' ler:120 
	{
		chk=0;
		for (j=0;j<nez;j++)
			if (I1[i]==I2[j]) //aynı noktalar parentlarda 1'e bentde 0 karşılık geliyor.
				chk=1;
		if (chk==0)
		{
			JB[kt]=I1[i]; //1 olan yerlerin indislerini tutup child'da ilgili indisleri 1 yaptık.
			kt = kt + 1;
			CH[I1[i]]=1;
		}
	}
	
	for (i=0;i<nez;i++)
	{
		chk=0;
		for (j=0;j<nez;j++)
			if (I2[i]==I1[j]) //aynı noktalar parentda 1'e bentde 0 karşılık geliyor.
				chk=1;
		if (chk==0)
		{
			JB[kt]=I2[i];//1 olan yerlerin indislerini tutup childda ilgili indisleri 1 yaptık.
			kt = kt + 1; //printf("kt=%d", kt);
			CH[I2[i]]=1;
		}
		//printf("kt:%d", kt);
	}
	
	for (i=0;i<kt/2;i++)//çaprazlama yaptı.
	{
		chk=0;
		while (chk==0)
		{
			chk=1;
			cek=cek+10;
			seed=(unsigned int) time(0)+cek;
			TRandomMersenne rg(seed);            // make instance of random number generator
			ir = rg.IRandom(0,kt-1);
			for (k=0;k<i;k++)
				if (PI[k]==ir)
					chk=0;
			if (chk==1)	PI[i]=ir;
		}
	}
	for (i=0;i<kt/2;i++)
		CH[JB[PI[i]]]=0;
	for (i=0;i<N;i++)
		if (CH[i]==2)
			printf("\nError...breed_new");
	j=bal_chk(CH);
	if (j!=N/2) //Balanced değilse; çocukta 0'lar değiştikten sonra kontrol için weight fonksiyonuna gidiyor.
	{
		printf("\nError..bal...breed_new %d; %d",i,weight(CH));
		return;
	}
	j=0;
	for (i=0;i<N;i++)
		if (CH[i]!=BNT[i])
		{
			cix[j]=i;//cix=bentden farklı olan pozisyon indeksi
			j=j+1;
		}
	if (j!=nez)
		printf("\nError..cix");

}


long double sumsse(long double *FW){
	
	int i;
	long double sum=0,tmp;
	
	for (i=0;i<N;i++){
		tmp=FW[i]*FW[i];
		sum=sum+(tmp-N)*(tmp-N);
	}
	return sum;
	
}



void make_bal(signed char *B)
{
	int i,chk,cbx=0;
	for (i=0;i<nez;i++)  // nlin/2 tanesini 1 yap ki dengeli hale gelsin.
	{
		chk=0;
		while (chk==0)
		{
			chk=1;
			cek=cek+10;
			seed=(unsigned int) time(0)+cek;
			TRandomMersenne rg(seed);            // make instance of random number generator
			ir = rg.IRandom(0,N-1);
			if (B[ir]==0) //Bent fonksiyonunun bitleri kontrol ediliyor. 0 ise 1 yapılıyor.(8 adet bit)
			{
				B[ir]=1;
				bix[cbx]=ir;//Önceden 0 olup sonradan 1 yapılan yerlerin indisleri tutuluyor.
				cbx=cbx+1; //bent fonk.nun önceden 0 olup sonradan 1 olan yerlerinin sayısını tutuyor.
			}
			else
				chk=0;
		}
	}
}

void gen_bent(signed char *B)
{
	int i,j,k,PI[nlin],chk;

	for (i=0;i<nlin;i++)
	{
		chk=0;
		while (chk==0)
		{
			chk=1;
			cek=cek+10;
			seed=(unsigned int) time(0)+cek;
			TRandomMersenne rg(seed);            // make instance of random number generator
			ir = rg.IRandom(0,nlin-1);           //0 ile 15 arası rastgele sayı üretiyor.
			for (k=0;k<i;k++)
				if (PI[k]==ir) //aynı indisteki değer yeniden üretilmişse yeniden döngüye gir.kontrol et.
					chk=0;
			if (chk==1)	PI[i]=ir;//nlin sayısı kadar konum belirle.
		}
		//printf("PI[%d]=%d", i, ir);
	} 
	for (i=0;i<nlin;i++)
		//printf("\n B[%d]=%d", (i * nlin + j), (PI[i] * nlin + j));		
		for (j=0;j<nlin;j++)
			B[i*nlin+j]=H[PI[i]*nlin+j];//rastgele nlin kadar bit seçiyor. nlin*nlin (mesela 16*16=N) bent fonksiyonu oluşuyor.
}										// PI[i][j] iki boyutlu Hadamard matrisinden B[i][j] matrisi oluşturuldu.

int findmaxwh(long double *tt)  //FW'ler tt' a aktarılıyor.
{
	int i;
	long double D,Maxi=-1;
	for (i=0;i<N;i++)
	{
		D = tt[i];//printf("D=%d", tt[i]);
		if (tt[i]<0)
			D=-tt[i];
		if (D>Maxi)
			Maxi=D;
	}
	return ((int) Maxi);
}

void mutation_rnd(signed char *B, long double *FW)
{
	int i,j,chk,NL;

	cek=cek+10;
	seed=(unsigned int) time(0)+cek;
	TRandomMersenne rg(seed);            // make instance of random number generator
	ir = rg.IRandom(0,N-1);

	if (ir<2)
	{
		chk=0;
		while (chk==0)
		{
			chk=1;
			cek=cek+10;
			seed=(unsigned int) time(0)+cek;
			TRandomMersenne rgx(seed);            // make instance of random number generator
			ir1 = rgx.IRandom(0,N-1);

			cek=cek+10;
			seed=(unsigned int) time(0)+cek;
			TRandomMersenne rgy(seed);            // make instance of random number generator
			ir2 = rgy.IRandom(0,N-1);

			if (BNT[ir1]==0 && BNT[ir2]==0) 
			{
				if (B[ir1]!=B[ir2])
				{
					B[ir1]=B[ir1]^1;
					B[ir2]=B[ir2]^1;
				}
				else
					chk=0;
			}
			else
				chk=0;
		}

		fastwh(B,FW);

///////////////////////////////////////////////////////
		NL=N/2-findmaxwh(FW)/2;
		if (bnl<NL)
			bnl=NL;

//////////////////////////////////////////////////////

		if (scst==1)
			mutcost=sumsse(FW);
	}
	j=0;
	for (i=0;i<N;i++)
		if (B[i]!=BNT[i])
		{
			cix[j]=i;
			j=j+1;
		}
	if (j!=nez)
		printf("\nError..cix : mutation");

}




void tohex(int *TT, unsigned int *tt){
	
	int i,j;
	
	for (i=0;i<N/32;i++){
		tt[i]=0;
		for (j=31;j>=0;j--)
			tt[i]=(TT[i*32+j]<<(31-j))^tt[i];
	}
}

